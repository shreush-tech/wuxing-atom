// Legacy compatibility file. New UI uses acupointAtlas.ts.
// Terminology: acupressure / Tuiná, not “automassagem”.
export { acupointAtlas as selfMassagePoints } from './acupointAtlas'
