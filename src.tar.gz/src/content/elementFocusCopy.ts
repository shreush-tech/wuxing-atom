export const elementFocusCopy={
  wood:{glyph:'木',name:'Madeira',organs:'Fígado · Vesícula Biliar',phrase:'Movimento, adaptação e fluxo.'},
  fire:{glyph:'火',name:'Fogo',organs:'Coração · Intestino Delgado',phrase:'Ritmo, circulação e presença.'},
  earth:{glyph:'土',name:'Terra',organs:'Baço · Estômago',phrase:'Transformação, nutrição e estabilidade.'},
  metal:{glyph:'金',name:'Metal',organs:'Pulmão · Intestino Grosso',phrase:'Troca, organização e limites.'},
  water:{glyph:'水',name:'Água',organs:'Rim · Bexiga',phrase:'Reserva, profundidade e sustentação.'}
} as const
export type FocusElement=keyof typeof elementFocusCopy
