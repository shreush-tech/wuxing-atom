import type {ClinicalState} from '../clinical/types'

export type ResultArchitecture={
  hasResult:boolean
  primary:string|null
  secondary:string|null
  relationship:any|null
  confidenceLabel:string
}

export function resultArchitecture(c:ClinicalState):ResultArchitecture{
  const separation=Number(c.interview?.separation||0)
  const confidenceLabel=separation>=3
    ?'Padrão bem sustentado pelas suas respostas'
    :separation>=1
      ?'Padrão ganhando consistência'
      :'Sinais iniciais'

  return {
    hasResult:Boolean(c.interview?.canShowResult),
    primary:c.interview?.leadingPatternId||null,
    secondary:c.interview?.runnerUpPatternId||null,
    relationship:Array.isArray((c as any).relationships)
      ?(c as any).relationships[0]||null
      :(c as any).relationship||null,
    confidenceLabel
  }
}
