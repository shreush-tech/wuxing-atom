import {ClinicalProvider} from './clinical/store'
import {Scene} from './three/Scene'
import {SymptomExplorer} from './components/SymptomExplorer'
import {ClinicalDiagnosesSection} from './components/ClinicalDiagnosesSection'
import {JourneyGuide} from './components/JourneyGuide'
import {ThemeControls} from './components/ThemeControls'
import {EducationSection} from './components/EducationSection'
import {AcupointConstellation} from './components/AcupointConstellation'
import {ContactFooter} from './components/ContactFooter'
import {AtomHint} from './components/AtomHint'
import {ExperienceShell} from './components/ExperienceShell'
import {FocusProvider,useFocus} from './components/FocusContext'
import {ElementFocusCard} from './components/ElementFocusCard'
import {ResultRevealGate} from './components/ResultRevealGate'
import {FinalResultExperience} from './components/FinalResultExperience'
import {AtomErrorBoundary} from './components/AtomErrorBoundary'
import './styles/app.css'

function FocusOverlay(){
  const {focus,setFocus}=useFocus()
  return <>
    <ElementFocusCard element={focus} onClose={()=>setFocus(null)}/>
  </>
}

export default function App(){
  return <ClinicalProvider>
    <FocusProvider>
      <ExperienceShell>
        <div className="page">
          <main className="app">
            <section className="scene-pane">
              <div className="experience-toolbar">
                <div className="brand"><span className="brand-mark">五</span><span>Wu Xing · mapa interativo</span></div>
                <ThemeControls/>
              </div>
              <AtomErrorBoundary><Scene/></AtomErrorBoundary>
            </section>
            <aside className="panel">
              <AtomHint/>
              <FocusOverlay/>
              <ResultRevealGate/>
              <JourneyGuide/>
              <SymptomExplorer/>
              <ClinicalDiagnosesSection/>
            </aside>
          </main>

          <FinalResultExperience/>
          <EducationSection/>
          <AcupointConstellation/>
          <ContactFooter/>
        </div>
      </ExperienceShell>
    </FocusProvider>
  </ClinicalProvider>
}
