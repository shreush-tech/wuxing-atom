import { useMemo, useState } from 'react'
import { WhyThisQuestion } from './WhyThisQuestion'
import { symptoms, primarySymptomIds } from '../clinical/symptoms'
import { questions } from '../clinical/questions'
import { useClinical } from '../clinical/store'
import { AdaptiveQuestionCard } from './AdaptiveQuestionCard'
import { SafetyGate } from './SafetyGate'
import { MicroInterview } from './MicroInterview'
import { LowBackDifferentialNote } from './LowBackDifferentialNote'
import { DiagnosticJourney } from './DiagnosticJourney'
import { DiagnosticConvergence } from './DiagnosticConvergence'
import { DifferentialSuspense } from './DifferentialSuspense'
import { RelationshipEmergenceNote } from './RelationshipEmergenceNote'
import { ResultGateway } from './ResultGateway'
import { SimpleJourney } from './SimpleJourney'

const norm=(s:string)=>s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')

export function SymptomExplorer(){
  const {selected,setAnswer,clinical,clear}=useClinical()
  const [search,setSearch]=useState('')

  const selectedIds=Object.entries(selected).filter(([,v])=>v==='yes').map(([k])=>k)
  const primary=primarySymptomIds.map(id=>symptoms.find(s=>s.id===id)!).filter(Boolean)
  const searchResults=useMemo(()=>{
    if(!search.trim()) return []
    const q=norm(search)
    return symptoms.filter(s=>s.category!=='seguranca').filter(s=>{
      const hay=[s.label,...(s.aliases||[])].map(norm).join(' ')
      return hay.includes(q)
    }).slice(0,12)
  },[search])

  return <div className="panel-inner">
    <div className="sheet-handle" aria-hidden="true"></div>
    <div className="panel-head">
      <div className="eyebrow">Leitura educativa · Medicina Chinesa</div>
      <h1>O que mais está incomodando você?</h1>
      <p className="lead">Toque no que reconhece. O mapa reage a combinações de sinais, não a um sintoma isolado.</p>
    </div>

    <div className="panel-scroll">
      <div className="symptom-grid">
        {primary.map(s=><button key={s.id} className={`symptom ${selected[s.id]==='yes'?'selected':''}`} onClick={()=>setAnswer(s.id,selected[s.id]==='yes'?'unknown':'yes')}>{s.label}</button>)}
      </div>

      <div className="search">
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Buscar outro sintoma…"/>
      </div>
      {search && <div className="symptom-grid search-results">
        {searchResults.map(s=><button key={s.id} className={`symptom ${selected[s.id]==='yes'?'selected':''}`} onClick={()=>setAnswer(s.id,'yes')}>{s.label}</button>)}
      </div>}

      {!!selectedIds.length && <>
        <div className="section-title">Meu mapa · toque para remover</div>
        <div className="selected-tray">
          {selectedIds.map(id=><button key={id} className="chip" onClick={()=>setAnswer(id,'unknown')}>{symptoms.find(s=>s.id===id)?.label} ×</button>)}
          <button className="chip clear" onClick={clear}>limpar</button>
        </div>
      </>}

      <SafetyGate/>
      <MicroInterview/>
      <LowBackDifferentialNote/>
      <AdaptiveQuestionCard/>

      
      
      
      
      
      <SimpleJourney/>
      <ResultGateway/>
      <div className="footer-note">Leitura educativa baseada em padrões da Medicina Chinesa. Não substitui avaliação médica. Quando necessário, a camada de segurança interrompe a experiência antes do resultado.</div>
    </div>
  </div>
}