import { elementFocusCopy,type FocusElement } from '../content/elementFocusCopy'

export function ElementFocusCard({element,onClose}:{element:FocusElement|null,onClose:()=>void}){
  if(!element)return null
  const x=elementFocusCopy[element]
  return <aside className="element-focus-card" aria-live="polite">
    <button className="focus-close" type="button" onClick={onClose} aria-label="Voltar ao mapa">×</button>
    <div className="focus-glyph">{x.glyph}</div>
    <div>
      <h3>{x.name}</h3>
      <p className="focus-organs">{x.organs}</p>
      <p>{x.phrase}</p>
    </div>
  </aside>
}
