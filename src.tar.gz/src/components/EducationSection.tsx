import { useClinical } from '../clinical/store'
import { PatternDetails } from './PatternDetails'

export function EducationSection(){
  const {clinical}=useClinical()
  const top=clinical.patterns[0]
  const relation=clinical.relationship

  return <section className="education-section" id="entenda-seu-mapa">
    <div className="education-eyebrow">Depois do mapa</div>
    <h2>Entenda o que apareceu</h2>
    <p className="education-lead">
      A experiência acima organiza combinações de sintomas segundo a estrutura tradicional usada na referência do projeto.
      O objetivo aqui é explicar o raciocínio de forma compreensível, não transformar o mapa em diagnóstico médico.
    </p>

    {clinical.interview.canShowResult && (relation || (top && top.raw>0)) ? <div className="education-card">
      <div>
        <div className="education-label">{relation ? 'Relação em destaque' : 'Padrão em destaque'}</div>
        <h3>{relation?.title || top.label}</h3>
        <p>{relation?.explanation || 'Este padrão foi o que reuniu maior quantidade de sinais entre as respostas selecionadas.'}</p>
      </div>
      {top && <PatternDetails patternId={top.id}/>}
    </div> : <div className="education-empty">
      Faça algumas escolhas no mapa para que esta seção passe a explicar os sinais que apareceram.
    </div>}
  </section>
}
