import { useClinical } from '../clinical/store'
import { patternLabels } from '../content/resultLabels'

export function AmbiguityNotice(){
  const {clinical}=useClinical()
  if(clinical.interview.readiness!=='ambiguous')return null
  const [a,b]=clinical.patterns.filter(p=>p.raw>0).slice(0,2)
  if(!a||!b)return null
  return <div className="ambiguity-notice">
    <div className="story-kicker">Mapa ainda aberto</div>
    <h3>Duas leituras continuam próximas.</h3>
    <div><span>{patternLabels[a.id]?.short||a.label}</span><i>ou</i><span>{patternLabels[b.id]?.short||b.label}</span></div>
    <p>Em vez de forçar uma conclusão, o sistema mantém as duas possibilidades visíveis. Uma avaliação presencial pode acrescentar informações que esta experiência deliberadamente não utiliza.</p>
  </div>
}
