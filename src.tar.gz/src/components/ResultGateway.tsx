import { useClinical } from '../clinical/store'

export function ResultGateway(){
  const {clinical}=useClinical()
  if(!clinical.interview.canShowResult)return null
  const go=()=>document.getElementById('result-story')?.scrollIntoView({behavior:'smooth',block:'start'})
  return <div className="result-gateway">
    <span>Seu mapa está pronto para uma primeira leitura</span>
    <strong>Veja o que apareceu — e por quê.</strong>
    <button type="button" onClick={go}>Abrir meu mapa</button>
    <small>Você poderá continuar refinando depois.</small>
  </div>
}
