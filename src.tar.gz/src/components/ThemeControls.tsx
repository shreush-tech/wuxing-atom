import {useEffect,useState} from 'react'
import {defaultTheme,themePresets,type ThemePreset} from '../content/themePresets'

export function ThemeControls(){
 const [theme,setTheme]=useState<ThemePreset>(defaultTheme)
 const apply=(id:ThemePreset)=>{
   setTheme(id)
   const t=themePresets[id]
   document.documentElement.style.setProperty('--user-bg',t.background)
   document.documentElement.style.setProperty('--user-surface',t.surface)
   document.documentElement.style.setProperty('--user-ink',t.text)
   document.documentElement.dataset.theme=id
 }
 useEffect(()=>apply(defaultTheme),[])
 return <div className="theme-controls" aria-label="Aparência">
   {(Object.keys(themePresets) as ThemePreset[]).map(id=>
     <button type="button" key={id} aria-pressed={theme===id} title={`Fundo ${themePresets[id].label}`} onClick={()=>apply(id)}>
       <span className="theme-dot" style={{background:themePresets[id].background}}/>
       <span className="theme-label">{themePresets[id].label}</span>
     </button>)}
 </div>
}
