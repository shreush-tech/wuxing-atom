import { symptoms } from './symptoms'
import { bookRulesV2 } from './bookRulesV2'
import type { AnswerState, PatternId, PatternScore, SymptomId } from './types'

type Selected=Record<string,AnswerState>

function weightFor(patternId:PatternId,symptomId:SymptomId){
  const s=symptoms.find(x=>x.id===symptomId)
  let w=s?.weights?.[patternId]||0
  const r=bookRulesV2.find(x=>x.id===patternId)
  const rw=r?.support.find(([id])=>id===symptomId)?.[1]||0
  return Math.max(w,rw)
}

export function chooseNextQuestions(selected:Selected,ranked:PatternScore[],limit=4):SymptomId[]{
  const lead=ranked[0], second=ranked[1], third=ranked[2]
  const contenders=[lead,second,third].filter(Boolean) as PatternScore[]
  if(!contenders.length)return []

  const candidates=symptoms.filter(s=>selected[s.id]===undefined || selected[s.id]==='unknown')
  const scored=candidates.map(s=>{
    const ws=contenders.map(p=>weightFor(p.id,s.id))
    const max=Math.max(...ws,0)
    const min=Math.min(...ws,0)
    const spread=max-min
    const relevance=ws.reduce((a,b)=>a+b,0)
    const leadBias=lead?weightFor(lead.id,s.id):0
    const askedPenalty=selected[s.id]==='unknown' ? .45 : 1
    const value=(spread*2.2 + relevance*.65 + leadBias*.35)*askedPenalty
    return {id:s.id,value}
  }).filter(x=>x.value>0)
    .sort((a,b)=>b.value-a.value)

  return [...new Set(scored.map(x=>x.id))].slice(0,limit)
}

export function computeReadiness(selected:Selected,ranked:PatternScore[]){
  const answered=Object.values(selected).filter(v=>v==='yes'||v==='no').length
  const yes=Object.values(selected).filter(v=>v==='yes').length
  const lead=ranked[0]
  const second=ranked[1]
  const separation=(lead?.raw||0)-(second?.raw||0)
  const info=Math.min(1,(answered*.08)+(yes*.06)+(Math.max(0,lead?.raw||0)*.045))

  let readiness:'starting'|'forming'|'refine'|'ready'|'ambiguous'='starting'
  let rationale='Estamos começando a entender seu mapa.'
  let canShowResult=false

  if(answered>=2 || yes>=2){
    readiness='forming'
    rationale='Seu mapa está ganhando forma.'
  }
  if((lead?.raw||0)>=5 && separation<2){
    readiness='ambiguous'
    rationale='Duas ou mais possibilidades tradicionais continuam próximas.'
  }
  if((lead?.raw||0)>=5 && separation>=2 && answered<5){
    readiness='refine'
    rationale='Já existe uma hipótese principal, mas algumas perguntas podem diferenciá-la melhor.'
  }
  if((lead?.raw||0)>=6 && separation>=2 && answered>=4){
    readiness='ready'
    rationale='Há sinais suficientes para uma primeira leitura educativa.'
    canShowResult=true
  }
  if((lead?.raw||0)>=7 && separation>=3){
    readiness='ready'
    rationale='O padrão principal está bem separado das alternativas atuais.'
    canShowResult=true
  }

  return {answered,yes,separation,info,readiness,rationale,canShowResult}
}
