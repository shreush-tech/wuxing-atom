export type ClinicalDiagnosisCategory =
  | 'dor_e_musculoesqueletico' | 'digestivo' | 'ginecologico'
  | 'neurologico' | 'respiratorio' | 'cardiometabolico'
  | 'endocrino' | 'urogenital' | 'dermatologico' | 'saude_mental' | 'outros'

export type ClinicalDiagnosisDef={
  id:string; label:string; aliases:string[]; category:ClinicalDiagnosisCategory;
  source:'uploaded_reference_book'; sourceScope:'index_or_named_disorder_section'
}

export const clinicalDiagnoses:ClinicalDiagnosisDef[]=[
 {id:'endometriosis',label:'Endometriose',aliases:['endometriose'],category:'ginecologico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'carpal_tunnel',label:'Síndrome do túnel do carpo',aliases:['tunel do carpo','túnel do carpo'],category:'dor_e_musculoesqueletico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'fibromyalgia',label:'Fibromialgia',aliases:['fibromialgia'],category:'dor_e_musculoesqueletico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'migraine',label:'Enxaqueca',aliases:['enxaqueca','enxaqueca crônica','migrânea'],category:'neurologico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'acid_reflux',label:'Refluxo',aliases:['refluxo','refluxo ácido'],category:'digestivo',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'peptic_ulcer',label:'Úlcera péptica',aliases:['úlcera','ulcera peptica'],category:'digestivo',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'ibs',label:'Síndrome do intestino irritável',aliases:['sii','ibs','intestino irritável'],category:'digestivo',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'crohns',label:'Doença de Crohn',aliases:['crohn'],category:'digestivo',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'diverticulitis',label:'Diverticulite',aliases:['diverticulite'],category:'digestivo',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'lumbar_disc_herniation',label:'Hérnia de disco lombar',aliases:['hérnia de disco','hernia de disco'],category:'dor_e_musculoesqueletico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'osteoarthritis',label:'Osteoartrite / artrose',aliases:['osteoartrite','artrose'],category:'dor_e_musculoesqueletico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'rheumatoid_arthritis',label:'Artrite reumatoide',aliases:['artrite reumatoide'],category:'dor_e_musculoesqueletico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'osteoporosis',label:'Osteoporose',aliases:['osteoporose'],category:'dor_e_musculoesqueletico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'gout',label:'Gota',aliases:['gota'],category:'dor_e_musculoesqueletico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'chronic_fatigue',label:'Síndrome da fadiga crônica',aliases:['fadiga crônica'],category:'outros',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'asthma',label:'Asma',aliases:['asma'],category:'respiratorio',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'allergic_rhinitis',label:'Rinite alérgica',aliases:['rinite'],category:'respiratorio',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'chronic_sinusitis',label:'Sinusite crônica',aliases:['sinusite'],category:'respiratorio',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'hypertension',label:'Hipertensão arterial',aliases:['hipertensão','pressão alta'],category:'cardiometabolico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'high_cholesterol',label:'Colesterol elevado',aliases:['colesterol alto','hipercolesterolemia'],category:'cardiometabolico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'diabetes',label:'Diabetes',aliases:['diabetes'],category:'endocrino',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'hypothyroidism',label:'Hipotireoidismo',aliases:['hipotireoidismo'],category:'endocrino',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'hyperthyroidism',label:'Hipertireoidismo',aliases:['hipertireoidismo'],category:'endocrino',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'menieres',label:'Doença de Ménière',aliases:['ménière','meniere'],category:'neurologico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'multiple_sclerosis',label:'Esclerose múltipla',aliases:['esclerose múltipla'],category:'neurologico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'parkinsons',label:'Doença de Parkinson',aliases:['parkinson'],category:'neurologico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'epilepsy',label:'Epilepsia',aliases:['epilepsia'],category:'neurologico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'anxiety',label:'Ansiedade',aliases:['ansiedade'],category:'saude_mental',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'depression',label:'Depressão',aliases:['depressão'],category:'saude_mental',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'bipolar',label:'Transtorno bipolar',aliases:['bipolar'],category:'saude_mental',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'ocd',label:'Transtorno obsessivo-compulsivo',aliases:['toc'],category:'saude_mental',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'bph',label:'Hiperplasia prostática benigna',aliases:['hpB','próstata aumentada'],category:'urogenital',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'chronic_prostatitis',label:'Prostatite crônica',aliases:['prostatite'],category:'urogenital',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'eczema',label:'Eczema',aliases:['eczema'],category:'dermatologico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'urticaria',label:'Urticária',aliases:['urticária'],category:'dermatologico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'},
 {id:'alopecia_areata',label:'Alopecia areata',aliases:['alopecia areata'],category:'dermatologico',source:'uploaded_reference_book',sourceScope:'index_or_named_disorder_section'}
]

const norm=(v:string)=>v.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim()
export function searchClinicalDiagnoses(q:string){
 const x=norm(q); if(!x)return clinicalDiagnoses.slice(0,10)
 return clinicalDiagnoses.filter(d=>norm(d.label).includes(x)||d.aliases.some(a=>norm(a).includes(x))).slice(0,12)
}

export const clinicalDiagnosisPolicy={
 directElementWeight:0,
 directImbalanceWeight:0,
 mayPrioritizeDifferentialQuestions:true,
 requiresCurrentEvidenceForChineseMedicineImbalance:true,
 mayRemainUncorrelated:true
} as const
