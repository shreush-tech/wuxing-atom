import { Canvas } from '@react-three/fiber'
import { useMemo, useRef, useState } from 'react'
import * as THREE from 'three'
import type { ElementId } from '../clinical/types'
import { useClinical } from '../clinical/store'
import { Core } from './Core'
import { ElementBody } from './ElementBody'
import { RelationshipHalo } from './RelationshipHalo'
import { SymptomPulse } from './SymptomPulse'
import { HypothesisField } from './HypothesisField'
import { LivingDifferential } from './LivingDifferential'
import { ConvergencePulse } from './ConvergencePulse'
import { EmergentRelationship } from './EmergentRelationship'
import { RevealConductor } from './RevealConductor'
import { CameraRig } from './CameraRig'
import { ClassicalNetwork } from './ClassicalNetwork'
import { InteractionRig } from './InteractionRig'
import { ZoomRig } from './ZoomRig'
import { elementMeta } from '../content/elements'
import { detectQualityTier, qualityConfig } from '../quality'
import { createInteractionState } from './interactionState'
import { WebGLFallback } from './WebGLFallback'
import { AtmosphereDust } from './AtmosphereDust'
import { SculpturalOrbits } from './SculpturalOrbits'
import { CoreAura } from './CoreAura'
import { SelectionRipple } from './SelectionRipple'
import { DepthVeil } from './DepthVeil'
import { GalleryLightMotion } from './GalleryLightMotion'
import { ClinicalVisualDynamics } from './ClinicalVisualDynamics'
import { ClinicalRelationshipDynamics } from './ClinicalRelationshipDynamics'
import { useFocus } from '../components/FocusContext'
import { RelationshipTapTarget } from './RelationshipTapTarget'
import { NucleusAbsorptionPulse } from './NucleusAbsorptionPulse'
import { LiveClinicalChoreography } from './LiveClinicalChoreography'

const ids:ElementId[]=['wood','fire','earth','metal','water']

function hasWebGL(){
  if(typeof document==='undefined')return true
  try{
    const c=document.createElement('canvas')
    return !!(c.getContext('webgl2')||c.getContext('webgl'))
  }catch{return false}
}

function World({focus,pulseKey,onFocus,waterSegments,particles}:{focus:ElementId|null,pulseKey:number,onFocus:(id:ElementId)=>void,waterSegments:number,particles:number}){
  const {clinical}=useClinical()
  const top=clinical.patterns[0]
  const resultMode=clinical.interview.canShowResult && (!!clinical.relationship || !!(top && top.raw>0))
  const sculpture=useRef<THREE.Group>(null!)
  const interaction=useRef(createInteractionState())

  return <>
    <ambientLight intensity={.58}/>
    <hemisphereLight intensity={1.02} color="#fffdf8" groundColor="#c9c0b2"/>
    <directionalLight position={[5,7,8]} intensity={2.15} color="#fffaf0"/>
    <directionalLight position={[-6,1,-4]} intensity={.62} color="#e7edf0"/>

    <group ref={sculpture} rotation={[.1,-.28,.05]}>
      <ClassicalNetwork visibility={resultMode ? .55 : 0}/>
      <SelectionRipple/>
        <NucleusAbsorptionPulse/>
        <CoreAura/>
        <Core/>
      {ids.map(id=><ClinicalVisualDynamics key={id} element={id}>
          <LiveClinicalChoreography clinical={clinical} element={id}>
            <ElementBody id={id} state={clinical.elements[id]} onSelect={onFocus} waterSegments={waterSegments} focused={focus===id}/>
          </LiveClinicalChoreography>
        </ClinicalVisualDynamics>) }
      {clinical.relationship && <>
        <RelationshipTapTarget/>
        <ClinicalRelationshipDynamics>
          <EmergentRelationship><RelationshipHalo relationship={clinical.relationship} maxParticles={particles}/></EmergentRelationship>
        </ClinicalRelationshipDynamics>
      </>} 
      <DepthVeil/>
        <GalleryLightMotion/>
        <AtmosphereDust/>
        <SculpturalOrbits/>
        <HypothesisField/>
        <ConvergencePulse/>
        <RevealConductor/>
        <SymptomPulse pulseKey={pulseKey}/>
    </group>

    <InteractionRig group={sculpture} interaction={interaction}/>
    <ZoomRig interaction={interaction}/>
        <CameraRig relationship={clinical.relationship} focus={focus} resultMode={resultMode} interaction={interaction}/>
  </>
}

export function Scene(){
  const {responseRevision}=useClinical()
  const {focus,setFocus}=useFocus()
  const tier=useMemo(()=>detectQualityTier(),[])
  const supported=useMemo(()=>hasWebGL(),[])
  const qc=qualityConfig[tier]
  const pulseKey=responseRevision

  const reset=()=>{
    setFocus(null)
    window.dispatchEvent(new Event('wuxing-reset-view'))
  }

  if(!supported)return <div className="scene-shell"><WebGLFallback/></div>

  return <div className="scene-shell">
    <Canvas camera={{position:[.2,1.4,10.2],fov:42}} dpr={qc.dpr} gl={{antialias:tier!=='low',powerPreference:'high-performance'}}>
      <color attach="background" args={['#f2efe8']}/>
      <fog attach="fog" args={['#f2efe8',12,24]}/>
      <World focus={focus} pulseKey={pulseKey} onFocus={setFocus} waterSegments={qc.waterSegments} particles={qc.particles}/>
    </Canvas>

    <button className="reset-view" onClick={reset} aria-label="Recentrar mapa 3D">recentrar</button>
    <div className="scene-hint">arraste para girar · pinça/scroll para aproximar · duplo toque para recenter</div>

    <div className={`focus-label ${focus?'on':''}`} aria-live="polite">
      {focus && <>
        <div className="focus-char">{elementMeta[focus].char}</div>
        <div className="focus-name">{elementMeta[focus].name}</div>
        <div className="focus-sub">{elementMeta[focus].organs}</div>
        <div className="focus-keywords">{elementMeta[focus].keywords}</div>
      </>}
    </div>
  </div>
}