import { useFrame } from '@react-three/fiber'
import { useRef } from 'react'
import * as THREE from 'three'
import type { ElementId, ElementVisualState } from '../clinical/types'
import { WoodBody } from './WoodBody'
import { FireBody } from './FireBody'
import { EarthBody } from './EarthBody'
import { MetalBody } from './MetalBody'
import { WaterBody } from './WaterBody'
import { elementVisualIdentity } from '../content/elementVisualIdentity'
import { ElementFocusHalo } from './ElementFocusHalo'

const canonicalAnchors:Record<ElementId,THREE.Vector3>={
  fire:new THREE.Vector3(0,2.78,.14),
  earth:new THREE.Vector3(2.62,.82,-.18),
  metal:new THREE.Vector3(1.64,-2.24,.16),
  water:new THREE.Vector3(-1.64,-2.24,-.12),
  wood:new THREE.Vector3(-2.62,.82,.22),
}

const driftPhase:Record<ElementId,number>={
  fire:.2,
  earth:1.4,
  metal:2.7,
  water:4.0,
  wood:5.2,
}

/**
 * Canonical local composition:
 * Fire remains the apex of the Five-Element star.
 * The entire sculpture may still be rotated by the user in 3D.
 * Individual bodies breathe/drift subtly around their anchors instead of
 * completing full revolutions that would destroy the pentagram orientation.
 */
export function orbitPosition(id:ElementId,t:number){
  const anchor=canonicalAnchors[id]
  const phase=driftPhase[id]
  const drift=new THREE.Vector3(
    Math.sin(t*.72+phase)*.085,
    Math.cos(t*.61+phase)*.055,
    Math.sin(t*.53+phase)*.12
  )
  return anchor.clone().add(drift)
}

function GlassVessel({id}:{id:ElementId}){
  const tint:Record<ElementId,string>={
    wood:'#698675',fire:'#d47b61',earth:'#a8895e',metal:'#b8c0c5',water:'#527d91'
  }
  return <>
    <mesh scale={1.34}>
      <sphereGeometry args={[.64,36,36]}/>
      <meshPhysicalMaterial color={tint[id]} transparent opacity={.13} roughness={.12} metalness={.02} clearcoat={1} clearcoatRoughness={.08} depthWrite={false}/>
    </mesh>
    <mesh scale={1.39}>
      <sphereGeometry args={[.64,28,28]}/>
      <meshBasicMaterial color="#ffffff" transparent opacity={.025} wireframe depthWrite={false}/>
    </mesh>
  </>
}

function SpecializedBody({id,state,onSelect,waterSegments}:{id:ElementId,state:ElementVisualState,onSelect:(id:ElementId)=>void,waterSegments:number}){
  const click=()=>onSelect(id)
  if(id==='wood') return <WoodBody state={state} onClick={click}/>
  if(id==='fire') return <FireBody state={state} onClick={click}/>
  if(id==='earth') return <EarthBody state={state} onClick={click}/>
  if(id==='metal') return <MetalBody state={state} onClick={click}/>
  return <WaterBody state={state} onClick={click} segments={waterSegments}/>
}

export function ElementBody({id,state,onSelect,waterSegments=64,focused=false}:{id:ElementId,state:ElementVisualState,onSelect:(id:ElementId)=>void,waterSegments?:number,focused?:boolean}){
  const carrier=useRef<THREE.Group>(null!)
  const reducedMotion=typeof window!=='undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
  useFrame(({clock},dt)=>{
    const now=clock.getElapsedTime()
    const d=elementVisualIdentity[id]
    const p=orbitPosition(id,reducedMotion?0:now*.10)
    carrier.current.position.lerp(p,Math.min(1,dt*3.1))
    const presence=.96+state.activity*.10
    const breath=reducedMotion?1:1+Math.sin(now*d.breath+driftPhase[id])*.008
    const target=presence*breath
    const current=carrier.current.scale.x
    const next=THREE.MathUtils.lerp(current,target,Math.min(1,dt*3.4))
    carrier.current.scale.setScalar(next)
    carrier.current.rotation.y=reducedMotion?0:Math.sin(now*d.rotation+driftPhase[id])*.025
  })
  return <group ref={carrier}>
    {focused && <ElementFocusHalo active/>}
    <GlassVessel id={id}/>
    <SpecializedBody id={id} state={state} onSelect={onSelect} waterSegments={waterSegments}/>
  </group>
}
