import { useFrame } from '@react-three/fiber'
import { useRef } from 'react'
import * as THREE from 'three'

export function Core(){
  const outer=useRef<THREE.Mesh>(null!)
  const inner=useRef<THREE.Mesh>(null!)
  const ring=useRef<THREE.Mesh>(null!)

  useFrame(({clock})=>{
    const t=clock.getElapsedTime()
    inner.current.rotation.x=t*.041
    inner.current.rotation.y=-t*.058
    outer.current.scale.setScalar(1+Math.sin(t*.52)*.008)
    ring.current.rotation.x=t*.035
    ring.current.rotation.z=-t*.022
    const mat=ring.current.material as THREE.MeshBasicMaterial
    mat.opacity=.045+.018*(.5+.5*Math.sin(t*.48))
  })

  return <>
    <mesh ref={outer}>
      <icosahedronGeometry args={[1.02,6]}/>
      <meshPhysicalMaterial color="#eee9dd" roughness={.16} transmission={.31} thickness={1.6} clearcoat={.45} clearcoatRoughness={.18}/>
    </mesh>
    <mesh ref={inner}>
      <icosahedronGeometry args={[.66,4]}/>
      <meshStandardMaterial color="#cfc5b5" transparent opacity={.18} roughness={.78}/>
    </mesh>
    <mesh ref={ring} rotation={[1.2,.2,.4]}>
      <torusGeometry args={[1.18,.009,8,128]}/>
      <meshBasicMaterial color="#8e877c" transparent opacity={.05}/>
    </mesh>
  </>
}
