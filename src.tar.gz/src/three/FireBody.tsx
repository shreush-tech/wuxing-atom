import { useFrame } from '@react-three/fiber'
import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import type { ElementVisualState } from '../clinical/types'
import { fireVertex, fireFragment } from './shaders'

export function FireBody({state,onClick}:{state:ElementVisualState,onClick:()=>void}){
  const outer=useRef<THREE.Mesh>(null!)
  const inner=useRef<THREE.Mesh>(null!)

  const material=useMemo(()=>new THREE.ShaderMaterial({
    vertexShader:fireVertex,
    fragmentShader:fireFragment,
    transparent:true,
    depthWrite:false,
    uniforms:{
      uTime:{value:0},
      uHeat:{value:0},
      uActivity:{value:0},
      uExcess:{value:0},
      uBase:{value:new THREE.Color('#a4574c')},
      uHot:{value:new THREE.Color('#efb18d')}
    }
  }),[])

  useFrame(({clock})=>{
    const t=clock.getElapsedTime()
    material.uniforms.uTime.value=t
    material.uniforms.uHeat.value=THREE.MathUtils.lerp(material.uniforms.uHeat.value,state.heat,.06)
    material.uniforms.uActivity.value=THREE.MathUtils.lerp(material.uniforms.uActivity.value,state.activity,.06)
    material.uniforms.uExcess.value=THREE.MathUtils.lerp(material.uniforms.uExcess.value,state.excess,.06)
    outer.current.rotation.y=-t*(.07+.06*state.heat)
    inner.current.rotation.x=-t*.13
    inner.current.rotation.z=t*.08
    inner.current.scale.setScalar(.70+Math.sin(t*1.6)*.022)
  })

  return <group onClick={(e)=>{e.stopPropagation();onClick()}}>
    <mesh ref={outer} material={material}>
      <icosahedronGeometry args={[.63,5]}/>
    </mesh>
    <mesh ref={inner}>
      <icosahedronGeometry args={[.39,3]}/>
      <meshBasicMaterial color="#f2c7ad" transparent opacity={.07+state.activity*.08} depthWrite={false}/>
    </mesh>
  </group>
}
