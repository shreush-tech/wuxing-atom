import { useFrame } from '@react-three/fiber'
import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import type { ElementVisualState } from '../clinical/types'
import { woodVertex, woodFragment } from './shaders'

function Branch({a,b,r,material}:{a:THREE.Vector3,b:THREE.Vector3,r:number,material:THREE.ShaderMaterial}){
  const dir=b.clone().sub(a)
  const len=dir.length()
  const mid=a.clone().add(b).multiplyScalar(.5)
  const q=new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),dir.clone().normalize())
  return <mesh position={mid} quaternion={q} material={material}>
    <capsuleGeometry args={[r,Math.max(.01,len-r*2),8,14]}/>
  </mesh>
}

export function WoodBody({state,onClick}:{state:ElementVisualState,onClick:()=>void}){
  const group=useRef<THREE.Group>(null!)
  const material=useMemo(()=>new THREE.ShaderMaterial({
    vertexShader:woodVertex,
    fragmentShader:woodFragment,
    uniforms:{
      uTime:{value:0},
      uStagnation:{value:0},
      uActivity:{value:0},
      uDark:{value:new THREE.Color('#304d39')},
      uLight:{value:new THREE.Color('#6e8870')}
    }
  }),[])

  const tree=useMemo(()=>{
    const pts=[
      [new THREE.Vector3(0,-.72,0), new THREE.Vector3(.02,-.08,.02), .17],
      [new THREE.Vector3(.02,-.08,.02), new THREE.Vector3(-.13,.45,.06), .145],
      [new THREE.Vector3(-.13,.45,.06), new THREE.Vector3(.02,.83,.03), .105],
      [new THREE.Vector3(-.06,.18,.04), new THREE.Vector3(-.50,.46,.13), .085],
      [new THREE.Vector3(-.50,.46,.13), new THREE.Vector3(-.68,.72,.21), .055],
      [new THREE.Vector3(-.10,.41,.02), new THREE.Vector3(.34,.61,-.12), .078],
      [new THREE.Vector3(.34,.61,-.12), new THREE.Vector3(.58,.84,-.18), .05],
      [new THREE.Vector3(.00,-.12,.02), new THREE.Vector3(.38,.10,.18), .075],
      [new THREE.Vector3(.38,.10,.18), new THREE.Vector3(.59,.31,.28), .048],
      [new THREE.Vector3(-.02,.58,.02), new THREE.Vector3(-.34,.78,-.18), .06],
    ] as [THREE.Vector3,THREE.Vector3,number][]
    return pts
  },[])

  useFrame(({clock})=>{
    const t=clock.getElapsedTime()
    material.uniforms.uTime.value=t
    material.uniforms.uStagnation.value=THREE.MathUtils.lerp(material.uniforms.uStagnation.value,state.stagnation,.06)
    material.uniforms.uActivity.value=THREE.MathUtils.lerp(material.uniforms.uActivity.value,state.activity,.06)
    group.current.rotation.y+=.00045+.00055*state.activity
    group.current.rotation.z=Math.sin(t*.31)*(.018+.042*state.stagnation)
  })

  return <group ref={group} onClick={(e)=>{e.stopPropagation();onClick()}}>
    {tree.map(([a,b,r],i)=><Branch key={i} a={a} b={b} r={r} material={material}/>)}
  </group>
}
