import { useFrame, useThree } from '@react-three/fiber'
import { useEffect, useRef, type RefObject } from 'react'
import * as THREE from 'three'
import type { InteractionStateRef } from './interactionState'

const START_ROTATION=new THREE.Euler(.1,-.28,.05)

export function InteractionRig({group,interaction}:{group:RefObject<THREE.Group>,interaction:InteractionStateRef}){
  const {gl}=useThree()
  const dragging=useRef(false)
  const pointerId=useRef<number|null>(null)
  const last=useRef({x:0,y:0})
  const velocity=useRef({x:0,y:0,z:0})
  const idle=useRef(0)
  const resetTarget=useRef(false)

  useEffect(()=>{
    const el=gl.domElement

    const down=(e:PointerEvent)=>{
      interaction.current.activePointers.add(e.pointerId)
      interaction.current.lastManualAt=performance.now()
      interaction.current.isManipulating=true
      idle.current=0

      // Rotation is single-pointer only. The second pointer belongs to pinch zoom.
      if(interaction.current.activePointers.size===1){
        dragging.current=true
        pointerId.current=e.pointerId
        last.current={x:e.clientX,y:e.clientY}
        velocity.current={x:0,y:0,z:0}
        el.setPointerCapture?.(e.pointerId)
      } else {
        dragging.current=false
      }
    }

    const move=(e:PointerEvent)=>{
      if(!interaction.current.activePointers.has(e.pointerId))return
      interaction.current.lastManualAt=performance.now()
      if(interaction.current.activePointers.size!==1 || !dragging.current || pointerId.current!==e.pointerId || !group.current)return

      const dx=e.clientX-last.current.x
      const dy=e.clientY-last.current.y
      last.current={x:e.clientX,y:e.clientY}
      const vx=dx*.0044
      const vy=dy*.0044
      // A small diagonal roll gives a restrained trackball feel without disorienting the user.
      const vz=(dx-dy)*.00055
      velocity.current={x:vx,y:vy,z:vz}
      group.current.rotation.y+=vx
      group.current.rotation.x+=vy
      group.current.rotation.z+=vz
    }

    const up=(e:PointerEvent)=>{
      interaction.current.activePointers.delete(e.pointerId)
      if(pointerId.current===e.pointerId){
        dragging.current=false
        pointerId.current=null
        try{el.releasePointerCapture?.(e.pointerId)}catch{}
      }
      interaction.current.isManipulating=interaction.current.activePointers.size>0
      interaction.current.lastManualAt=performance.now()
    }

    const reset=()=>{
      resetTarget.current=true
      velocity.current={x:0,y:0,z:0}
      idle.current=0
    }

    el.addEventListener('pointerdown',down)
    el.addEventListener('pointermove',move)
    el.addEventListener('pointerup',up)
    el.addEventListener('pointercancel',up)
    window.addEventListener('wuxing-reset-view',reset as EventListener)
    return ()=>{
      el.removeEventListener('pointerdown',down)
      el.removeEventListener('pointermove',move)
      el.removeEventListener('pointerup',up)
      el.removeEventListener('pointercancel',up)
      window.removeEventListener('wuxing-reset-view',reset as EventListener)
    }
  },[gl,group,interaction])

  useFrame((_,dt)=>{
    if(!group.current)return

    if(resetTarget.current){
      group.current.rotation.x=THREE.MathUtils.damp(group.current.rotation.x,START_ROTATION.x,8,dt)
      group.current.rotation.y=THREE.MathUtils.damp(group.current.rotation.y,START_ROTATION.y,8,dt)
      group.current.rotation.z=THREE.MathUtils.damp(group.current.rotation.z,START_ROTATION.z,8,dt)
      if(Math.abs(group.current.rotation.x-START_ROTATION.x)<.003 && Math.abs(group.current.rotation.y-START_ROTATION.y)<.003 && Math.abs(group.current.rotation.z-START_ROTATION.z)<.003){
        group.current.rotation.copy(START_ROTATION)
        resetTarget.current=false
      }
      return
    }

    if(!dragging.current && interaction.current.activePointers.size<2){
      group.current.rotation.y+=velocity.current.x
      group.current.rotation.x+=velocity.current.y
      group.current.rotation.z+=velocity.current.z
      const friction=Math.pow(.055,dt)
      velocity.current.x*=friction
      velocity.current.y*=friction
      velocity.current.z*=friction
      idle.current+=dt

      if(idle.current>2.2 && Math.abs(velocity.current.x)<.0002 && Math.abs(velocity.current.y)<.0002){
        group.current.rotation.y+=dt*.018
      }
    }
    group.current.rotation.x=THREE.MathUtils.clamp(group.current.rotation.x,-1.35,1.35)
    group.current.rotation.z=THREE.MathUtils.clamp(group.current.rotation.z,-.55,.55)
  })

  return null
}
