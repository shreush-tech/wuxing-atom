import { useFrame } from '@react-three/fiber'
import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import type { ElementVisualState } from '../clinical/types'
import { waterVertex, waterFragment } from './shaders'

export function WaterBody({state,onClick,segments=64}:{state:ElementVisualState,onClick:()=>void,segments?:number}){
  const outer=useRef<THREE.Mesh>(null!)
  const core=useRef<THREE.Mesh>(null!)
  const material=useMemo(()=>new THREE.ShaderMaterial({
    vertexShader:waterVertex,
    fragmentShader:waterFragment,
    transparent:true,
    depthWrite:false,
    uniforms:{
      uTime:{value:0},uActivity:{value:0},uCold:{value:0},uHeat:{value:0},
      uDeep:{value:new THREE.Color('#244f5e')},uLight:{value:new THREE.Color('#8eb0b7')}
    }
  }),[])

  useFrame(({clock})=>{
    const t=clock.getElapsedTime()
    material.uniforms.uTime.value=t
    material.uniforms.uActivity.value=THREE.MathUtils.lerp(material.uniforms.uActivity.value,state.activity,.06)
    material.uniforms.uCold.value=THREE.MathUtils.lerp(material.uniforms.uCold.value,state.cold,.06)
    material.uniforms.uHeat.value=THREE.MathUtils.lerp(material.uniforms.uHeat.value,state.heat,.06)
    outer.current.rotation.y=t*.018
    outer.current.rotation.z=Math.sin(t*.28)*.025
    core.current.scale.setScalar(.71+Math.sin(t*.78)*.015)
  })

  return <group onClick={(e)=>{e.stopPropagation();onClick()}}>
    <mesh ref={outer} material={material}><sphereGeometry args={[.62,segments,segments]}/></mesh>
    <mesh ref={core}><sphereGeometry args={[.40,Math.max(24,Math.floor(segments*.55)),Math.max(24,Math.floor(segments*.55))]}/><meshBasicMaterial color="#abc5c9" transparent opacity={.055} depthWrite={false}/></mesh>
  </group>
}
