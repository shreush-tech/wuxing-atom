import { useFrame } from '@react-three/fiber'
import { useRef } from 'react'
import * as THREE from 'three'
import type { ElementVisualState } from '../clinical/types'

export function EarthBody({state,onClick}:{state:ElementVisualState,onClick:()=>void}){
  const ref=useRef<THREE.Group>(null!)
  const stone=useRef<THREE.Mesh>(null!)
  useFrame(({clock})=>{
    const t=clock.getElapsedTime()
    const instability=state.deficiency*.028
    ref.current.rotation.x=Math.sin(t*.28)*instability
    ref.current.rotation.z=Math.cos(t*.24)*instability
    ref.current.rotation.y+=.00045
    const compression=1-state.cold*.018
    ref.current.scale.lerp(new THREE.Vector3(1.01,compression,.99),.035)
    stone.current.rotation.y+=.00018
  })
  return <group ref={ref} onClick={(e)=>{e.stopPropagation();onClick()}}>
    <mesh ref={stone}>
      <dodecahedronGeometry args={[.64,2]}/>
      <meshStandardMaterial color="#aa8756" roughness={.96} metalness={0}/>
    </mesh>
    <mesh scale={1.035}>
      <dodecahedronGeometry args={[.64,1]}/>
      <meshBasicMaterial color="#d8c6a7" wireframe transparent opacity={.055} depthWrite={false}/>
    </mesh>
  </group>
}
