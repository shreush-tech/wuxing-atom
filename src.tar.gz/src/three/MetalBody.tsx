import { useFrame } from '@react-three/fiber'
import { useRef } from 'react'
import * as THREE from 'three'
import type { ElementVisualState } from '../clinical/types'

export function MetalBody({state,onClick}:{state:ElementVisualState,onClick:()=>void}){
  const ref=useRef<THREE.Mesh>(null!)
  useFrame(({clock})=>{
    const t=clock.getElapsedTime()
    ref.current.rotation.x=t*.05
    ref.current.rotation.y=t*.075
    ref.current.scale.setScalar(1+Math.sin(t*.65)*(.009+state.deficiency*.006))
  })
  return <mesh ref={ref} onClick={(e)=>{e.stopPropagation();onClick()}}>
    <icosahedronGeometry args={[.60,2]}/>
    <meshPhysicalMaterial color="#b8b4aa" roughness={.28+state.deficiency*.10} metalness={.72} clearcoat={.22} clearcoatRoughness={.20}/>
  </mesh>
}
